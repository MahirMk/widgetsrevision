package com.example.widgetsrevision.widgetsrevision

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
