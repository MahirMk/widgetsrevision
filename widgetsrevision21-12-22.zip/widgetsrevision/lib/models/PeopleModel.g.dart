// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'PeopleModel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

People _$PeopleFromJson(Map<String, dynamic> json) => People(
      name: json['name'] as String?,
      id: json['id'] as int?,
    );

Map<String, dynamic> _$PeopleToJson(People instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
