import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

class MyPrimaryButton extends StatelessWidget {

  final VoidCallback? onClick;
  final String? btnText;
  final Widget? myicon;

  const MyPrimaryButton(
      {super.key, required this.onClick, this.btnText, this.myicon});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 80.w,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: Theme.of(context).primaryColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: onClick,
        icon: myicon ?? const SizedBox.shrink(),
        label: Text(btnText!, style: Theme.of(context).textTheme.button),
      ),
    );
  }
}
