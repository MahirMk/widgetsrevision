import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:widgetsrevision/resources/StyleResources.dart';

class MyTextFormField extends StatelessWidget {

 final TextEditingController? myController;
 final TextInputType? myTextInputType;
 final ValueChanged? myOnChanged;
 final FormFieldValidator? myValidator;
 final String? myHintText;
 final String? myLabel;
 final VoidCallback? onClick;
 final Widget? myIcon;
  const MyTextFormField({super.key, required this.myController,this.myOnChanged,this.myHintText,this.myValidator,this.myTextInputType,this.myLabel,this.onClick,this.myIcon});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 5.w,vertical: 3.h),
      child: TextFormField(
        controller: myController,
        keyboardType: myTextInputType,
        onChanged: myOnChanged,
        validator: myValidator,
        cursorColor: Theme.of(context).primaryColor,
        decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(width: 3, color: Theme.of(context).primaryColor),
              borderRadius: BorderRadius.circular(20.0),
            ),
            focusedBorder:  OutlineInputBorder(
              borderSide: BorderSide(width: 3, color: Theme.of(context).primaryColor),
              borderRadius: BorderRadius.circular(20.0),
            ),
            suffixIcon: myIcon,
          hintText: myHintText,
          label:  Text(myLabel!),
          hintStyle: TextStyle(wordSpacing: 1.w)
        ),
      ),
    );
  }
}
