import 'package:flutter/material.dart';

class StyleResources
{
  static Color purpleDarkColor = Colors.purple.shade900;
  static Color whiteColor = Colors.white;
  static TextStyle purpleTxtDarkColor =  TextStyle(color: Colors.purple.shade900);
}